This is the solution to the coding exercise provided by DocuSign. 
The Content of the folder are as follows:-
    1.) Solution.java File ( contains the main class )
    2.) HotWeather.java File ( contains the getters for the HotWeather details )
    3.) ColdWeather.java File ( contains the getters for the ColdWeather details )

Running the Program:-  
    In order to run the program just compile the Solution class ( javac Solution.java )
    and then run the program ( java Solution )

Output:- 
    The program first runs the default inputs given in the coding exercise and produces desired output and then
    lets you to enter your custom input to check other test cases.
